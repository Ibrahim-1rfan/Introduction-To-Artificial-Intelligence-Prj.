import numpy as np
import csv
import os
import atexit
import signal
import sys
import time

os.system('cls' if os.name == 'nt' else 'clear')

def generate_shell_masked_matrix(pixel_array, center, hidden_size1=47):
    cx, cy = center
    final_data = []
    img_size = 100

    for layer in range(1, hidden_size1 + 1):
        shell_row = [0] * (img_size * img_size)
        
        # Define shell bounds
        for y in range(cy - layer, cy + layer + 1):
            for x in range(cx - layer, cx + layer + 1):
                if x < 0 or x >= img_size or y < 0 or y >= img_size:
                    continue
                
                # Border condition for shell edge
                if x == cx - layer or x == cx + layer or y == cy - layer or y == cy + layer:
                    index = y * img_size + x
                    shell_row[index] = pixel_array[index]
        
        final_data.append(shell_row)
    
    return final_data

def normalize_grayscale_array(arr):
    arr = np.array(arr)
    # Normalize each shell separately and take mean
    normalized_shells = []
    for shell in arr:
        shell = np.array(shell)
        if np.max(shell) > 0:  # Avoid division by zero
            shell = shell / np.max(shell)
        normalized_shells.append(np.mean(shell))
    
    return np.array(normalized_shells).reshape(-1, 1)  # Return as (47, 1)

def preprocess_image(pixel_array, center):
    """Convert image to normalized shell averages"""
    shells = generate_shell_masked_matrix(pixel_array, center, 47)
    final = normalize_grayscale_array(shells)
    return final  # Already (47, 1)

def random_parameters():
    # Layer sizes
    input_size = 47
    hidden_size1 = 64   # First hidden layer
    hidden_size2 = 32   # Second hidden layer
    output_size = 2     # Output layer ("a" and "not a")
    
    # He initialization for ReLU
    W1 = np.random.randn(hidden_size1, input_size) * np.sqrt(2./input_size)
    b1 = np.zeros((hidden_size1, 1))
    
    W2 = np.random.randn(hidden_size2, hidden_size1) * np.sqrt(2./hidden_size1)
    b2 = np.zeros((hidden_size2, 1))
    
    W3 = np.random.randn(output_size, hidden_size2) * np.sqrt(2./hidden_size2)
    b3 = np.zeros((output_size, 1))
    
    return W1, b1, W2, b2, W3, b3

def load_parameters():
    params = {}
    param_names = ['W1', 'b1', 'W2', 'b2', 'W3', 'b3']
    
    # Check if all parameter files exist
    all_exist = all(os.path.exists(f"{name}.csv") for name in param_names)
    
    if all_exist:
        print("Loading existing parameters...")
        try:
            for name in param_names:
                params[name] = np.loadtxt(f"{name}.csv", delimiter=',')
                if name.startswith('b'):
                    params[name] = params[name].reshape(-1, 1)
                elif name == 'W3':
                    # Try new shape first, fall back to old shape if needed
                    try:
                        params[name] = params[name].reshape(2, 32)
                    except ValueError:
                        print("Existing W3 parameters don't match new architecture. Initializing new W3.")
                        params[name] = np.random.randn(2, 32) * np.sqrt(2./32)
                elif name == 'W2':
                    params[name] = params[name].reshape(32, 64)
                elif name == 'W1':
                    params[name] = params[name].reshape(64, 47)
            return (params['W1'], params['b1'], params['W2'], params['b2'], params['W3'], params['b3'])
        except ValueError as e:
            print(f"Parameter shape mismatch: {e}. Initializing new parameters.")
            return random_parameters()
    else:
        print("Initializing new parameters...")
        return random_parameters()

def Leaky_relu(Z, alpha=0.01):
    """Leaky ReLU activation function"""
    return np.where(Z > 0, Z, alpha * Z)

def softmax(Z):
    expZ = np.exp(Z - np.max(Z, axis=0))
    return expZ / np.sum(expZ, axis=0, keepdims=True)

def forward(X, W1, b1, W2, b2, W3, b3):
    # Layer 1 (input to hidden1)
    Z1 = np.dot(W1, X) + b1  # (64,47) @ (47,1) -> (64,1)
    A1 = Leaky_relu(Z1)
    
    # Layer 2 (hidden1 to hidden2)
    Z2 = np.dot(W2, A1) + b2  # (32,64) @ (64,1) -> (32,1)
    A2 = Leaky_relu(Z2)
    
    # Output layer (hidden2 to output)
    Z3 = np.dot(W3, A2) + b3  # (2,32) @ (32,1) -> (2,1)
    A3 = softmax(Z3)
    
    return Z1, A1, Z2, A2, A3

def one_hot(label):
    # Only two classes now: "a" and "not a"
    is_a = 1 if label.lower() == 'a' else 0
    one_hot_vector = np.zeros((2, 1))
    one_hot_vector[is_a] = 1
    return one_hot_vector

def backward(X, Z1, A1, Z2, A2, A3, W2, W3, y_true):
    # Single sample
    dZ3 = A3 - y_true              # (2,1)
    dW3 = np.dot(dZ3, A2.T)        # (2,1) @ (1,32) -> (2,32)
    db3 = dZ3
    
    dA2 = np.dot(W3.T, dZ3)        # (32,2) @ (2,1) -> (32,1)
    dZ2 = dA2 * np.where(Z2 > 0, 1.0, 0.01)
    dW2 = np.dot(dZ2, A1.T)        # (32,1) @ (1,64) -> (32,64)
    db2 = dZ2
    
    dA1 = np.dot(W2.T, dZ2)        # (64,32) @ (32,1) -> (64,1)
    dZ1 = dA1 * np.where(Z1 > 0, 1.0, 0.01)
    dW1 = np.dot(dZ1, X.T)         # (64,1) @ (1,47) -> (64,47)
    db1 = dZ1
    
    return dW1, db1, dW2, db2, dW3, db3

def save_parameters(W1, b1, W2, b2, W3, b3):
    params = {
        'W1': W1, 'b1': b1,
        'W2': W2, 'b2': b2,
        'W3': W3, 'b3': b3
    }
    
    for name, param in params.items():
        np.savetxt(f"{name}.csv", param, delimiter=',')

def train_image(pixel_array, label, center, W1, b1, W2, b2, W3, b3, alpha=0.001):
    # 1. Preprocess image
    X = preprocess_image(pixel_array, center)  # (47,1)
    
    # 2. Forward pass
    Z1, A1, Z2, A2, A3 = forward(X, W1, b1, W2, b2, W3, b3)
    
    # 3. Get predictions and loss
    y_true = one_hot(label)
    prediction = np.argmax(A3, axis=0)
    label_index = np.argmax(y_true)
    match = 1 if prediction == label_index else 0
    loss = -np.sum(y_true * np.log(A3 + 1e-8))
    
    # 4. Backpropagation
    dW1, db1, dW2, db2, dW3, db3 = backward(X, Z1, A1, Z2, A2, A3, W2, W3, y_true)
    
    # 5. Update parameters
    W1 -= alpha * dW1
    b1 -= alpha * db1
    W2 -= alpha * dW2
    b2 -= alpha * db2
    W3 -= alpha * dW3
    b3 -= alpha * db3
    
    return W1, b1, W2, b2, W3, b3, loss, match

def trainedimages():
    file = open("geeks.txt", "r")
    content = int(file.read())
    print(content)
    file.close()
    return content

def cleanup(imagecount):
    print("Cleaning up before exit...")
    file = open("geeks.txt", "w")
    file.write(str(imagecount))
    file.close()

def handle_signal(signum, frame, imagecount):
    print(f"\nSignal {signum} received. Cleaning up...")
    cleanup(imagecount)
    sys.exit(0)

def adjust_learning_rate(current_lr, loss_change, threshold=0.0005, increase_factor=1.05, decrease_factor=0.8):
    if loss_change < threshold:
        new_lr = current_lr * decrease_factor
    else:
        new_lr = current_lr * increase_factor
    return new_lr

def process_csv_rows(image_file, centre_file):
    # Initialize parameters
    W1, b1, W2, b2, W3, b3 = load_parameters()

    # Training configuration
    alpha = 0.01
    epoch = 0
    max_epochs = 100
    save_interval = 100
    accuracy_counter = 0
    current_image_counter = 0
    total_epoch_images = 1999    # in one dataset

    image_counter = trainedimages()
    counter = 0

    if image_counter != 0:
        counter = image_counter % total_epoch_images
        epochs = (image_counter - counter) / total_epoch_images
        epoch = int(epochs + 1)

    atexit.register(lambda: cleanup(image_counter))

    signal.signal(signal.SIGINT, lambda s, f: handle_signal(s, f, image_counter))
    signal.signal(signal.SIGTERM, lambda s, f: handle_signal(s, f, image_counter))

    while epoch < max_epochs:
        print(f"\nEpoch {epoch}")
        total_loss = []

        with open(image_file, 'r') as img_f, open(centre_file, 'r') as cntr_f:
            img_reader = csv.reader(img_f)
            cntr_reader = csv.reader(cntr_f)
            
            for i in range(counter):
                next(img_reader)
                next(cntr_reader)
            
            for img_row, cntr_row in zip(img_reader, cntr_reader):
                label = img_row[0]
                pixels = np.array(img_row[1:], dtype=np.int32)
                centre = (int(cntr_row[0]), int(cntr_row[1]))
                
                W1, b1, W2, b2, W3, b3, loss, match = train_image(
                    pixel_array=pixels,
                    label=label,
                    center=centre,
                    W1=W1, b1=b1,
                    W2=W2, b2=b2,
                    W3=W3, b3=b3,
                    alpha=alpha
                )
                
                total_loss.append(loss)
                image_counter += 1
                current_image_counter += 1
                if match == 1:
                    accuracy_counter += 1
                
                print(f"Processed {image_counter} images, Loss: {loss:.4f}, Match: {bool(match)}")

                if image_counter % save_interval == 0:
                    save_parameters(W1, b1, W2, b2, W3, b3)
                    print(f"Saved weights after {image_counter} images")

                # # Python code to illustrate append() mode
                if image_counter % 100 == 0:
                    accuracy = (round(accuracy_counter / current_image_counter, 2) * 100)
                    average_loss = round(sum(total_loss)/len(total_loss),4)

                    with open("LossTrack.txt", "a") as f1, open("AccuracyTrack.txt", "a") as f2:
                        # Append the average loss and accuracy to the files
                        f1.write(f"Epoch {epoch}, Image {image_counter}, Loss {average_loss} :\n ")
                        f2.write(f"Epoch {epoch}, Image {image_counter}, Accuracy {accuracy}% :\n ")
                        f1.close()
                        f2.close()
                    
                    accuracy_counter = 0
                    current_image_counter = 0

        with open("previous_loss.txt", "r") as file:
                previous_loss = float(file.read())   
                loss_change = average_loss - previous_loss 
                alpha = adjust_learning_rate(current_lr=alpha,loss_change=loss_change)
                file.close()    
        
        with open("previous_loss.txt", "w") as file:
            file.write(str(average_loss))
            file.close()
              
        # End of epoch
        epoch += 1
        summary = (
            f"\nEpoch {epoch - 1} complete\n"
            f"Total images: {image_counter}\n"
            f"Learning rate: {alpha:.6f}\n"
            f"Loss: {loss:.6f}\n"
            f"Accuracy: {accuracy:.6f}\n\n"
        )
        print(summary)
        with open("EpochSummary.txt", "a") as summary_file:
            summary_file.write(summary)
        
        # Save weights at end of epoch
        save_parameters(W1, b1, W2, b2, W3, b3)

# Start training
process_csv_rows("AB.csv", "BackupCentresAB.csv")