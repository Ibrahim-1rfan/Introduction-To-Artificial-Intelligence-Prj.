import numpy as np
import csv
import os
import time
from collections import deque
import sys
import atexit
import signal
import itertools

os.system('cls' if os.name == 'nt' else 'clear')


def batch_generator(image_file, centre_file, batch_size):
    with open(image_file, 'r') as img_f, open(centre_file, 'r') as cntr_f:
        img_reader = csv.reader(img_f)
        cntr_reader = csv.reader(cntr_f)
        
        while True:
            batch = []
            try:
                for _ in range(batch_size):
                    img_row = next(img_reader)
                    cntr_row = next(cntr_reader)
                    
                    label = img_row[0]
                    pixels = np.array(img_row[1:], dtype=np.float32)
                    center = (int(cntr_row[0]), int(cntr_row[1]))
                    
                    batch.append((pixels, label, center))
                yield batch
            except StopIteration:
                if batch:
                    yield batch
                break

# Image preprocessing
def preprocess_image(pixel_array, center, img_size=100):
    img_2d = np.array(pixel_array, dtype=np.float32).reshape(img_size, img_size)
    img_2d = (img_2d - np.mean(img_2d)) / (np.std(img_2d) + 1e-8)
    
    cx, cy = center
    start_x = max(0, cx - 32)
    end_x = min(img_size, cx + 32)
    start_y = max(0, cy - 32)
    end_y = min(img_size, cy + 32)
    
    cropped = img_2d[start_y:end_y, start_x:end_x]
    
    if cropped.shape != (64, 64):
        pad_width = [(0, 64 - cropped.shape[0]), (0, 64 - cropped.shape[1])]
        cropped = np.pad(cropped, pad_width, mode='constant')
    
    return cropped.reshape(-1, 1)


# One-hot encoding
def one_hot(label, num_classes=29):
    classes = [chr(i) for i in range(ord('A'), ord('Z')+1)] + ['del', 'nothing', 'space']
    label_to_index = {cls:idx for idx, cls in enumerate(classes)}
    one_hot_vector = np.zeros((num_classes, 1), dtype=np.float32)
    one_hot_vector[label_to_index[label]] = 1
    return one_hot_vector

# Network initialization
def initialize_parameters():
    input_size = 64*64
    conv1_size = 32
    conv2_size = 64
    fc1_size = 256
    fc2_size = 128
    output_size = 29
    
    W1 = np.random.randn(conv1_size, input_size).astype(np.float32) * np.sqrt(2./input_size)
    b1 = np.zeros((conv1_size, 1), dtype=np.float32)
    
    W2 = np.random.randn(conv2_size, conv1_size).astype(np.float32) * np.sqrt(2./conv1_size)
    b2 = np.zeros((conv2_size, 1), dtype=np.float32)
    
    W3 = np.random.randn(fc1_size, conv2_size).astype(np.float32) * np.sqrt(2./conv2_size)
    b3 = np.zeros((fc1_size, 1), dtype=np.float32)
    
    W4 = np.random.randn(fc2_size, fc1_size).astype(np.float32) * np.sqrt(2./fc1_size)
    b4 = np.zeros((fc2_size, 1), dtype=np.float32)
    
    W5 = np.random.randn(output_size, fc2_size).astype(np.float32) * np.sqrt(2./fc2_size)
    b5 = np.zeros((output_size, 1), dtype=np.float32)
    
    return W1, b1, W2, b2, W3, b3, W4, b4, W5, b5

def load_parameters():
    params = {}
    param_names = ['W1', 'b1', 'W2', 'b2', 'W3', 'b3', 'W4', 'b4' , 'W5', 'b5']
    
    # Check if all parameter files exist
    all_exist = all(os.path.exists(f"{name}.csv") for name in param_names)
    
    if all_exist:
        print("Loading existing parameters...")
        for name in param_names:
            params[name] = np.loadtxt(f"{name}.csv", delimiter=',')
            if name.startswith('b'):
                params[name] = params[name].reshape(-1, 1)
            elif name == 'W5':
                params[name] = params[name].reshape(29, 128)  # Adjust to your architecture
            elif name == 'W4':
                params[name] = params[name].reshape(128, 256)  # Adjust to your architecture
            elif name == 'W3':
                params[name] = params[name].reshape(256, 64)  # Adjust to your architecture
            elif name == 'W2':
                params[name] = params[name].reshape(64, 32)  # Adjust to your architecture
            elif name == 'W1':
                params[name] = params[name].reshape(32, 4096)  # Adjust to your architecture
        return (params['W1'], params['b1'], params['W2'], params['b2'], 
                params['W3'], params['b3'], params['W4'], params['b4'],params['W5'], params['b5'])
    else:
        print("Initializing new parameters...")
        return initialize_parameters()
# Activation functions

def save_parameters(W1, b1, W2, b2, W3, b3, W4, b4,W5, b5):
    params = {
        'W1': W1, 'b1': b1,
        'W2': W2, 'b2': b2,
        'W3': W3, 'b3': b3,
        'W4': W4, 'b4': b4,
        'W5': W5, 'b5': b5
    }
    
    for name, param in params.items():
        np.savetxt(f"{name}.csv", param, delimiter=',')
def elu(Z, alpha=1.0):
    return np.where(Z > 0, Z, alpha * (np.exp(Z) - 1))

def softmax(Z):
    expZ = np.exp(Z - np.max(Z))
    return expZ / (np.sum(expZ, axis=0, keepdims=True) + 1e-8)

# Forward pass
def forward(X, params):
    W1, b1, W2, b2, W3, b3, W4, b4, W5, b5 = params
    
    Z1 = np.dot(W1, X) + b1
    A1 = elu(Z1)
    
    Z2 = np.dot(W2, A1) + b2
    A2 = elu(Z2)
    
    Z3 = np.dot(W3, A2) + b3
    A3 = elu(Z3 + A1.mean(axis=0, keepdims=True))
    
    Z4 = np.dot(W4, A3) + b4
    A4 = elu(Z4)
    
    Z5 = np.dot(W5, A4) + b5
    A5 = softmax(Z5)
    
    cache = (X, Z1, A1, Z2, A2, Z3, A3, Z4, A4, Z5, A5)
    return cache, A5

# Backward pass
def backward(cache, params, y_true):
    X, Z1, A1, Z2, A2, Z3, A3, Z4, A4, Z5, A5 = cache
    W1, b1, W2, b2, W3, b3, W4, b4, W5, b5 = params
    
    dZ5 = A5 - y_true
    dW5 = np.dot(dZ5, A4.T)
    db5 = dZ5
    
    max_grad = 1.0
    grad_norm = np.linalg.norm(dZ5)
    if grad_norm > max_grad:
        dZ5 = dZ5 * (max_grad / grad_norm)
    
    dA4 = np.dot(W5.T, dZ5)
    dZ4 = dA4 * (Z4 > 0)
    dW4 = np.dot(dZ4, A3.T)
    db4 = dZ4
    
    dA3 = np.dot(W4.T, dZ4)
    dZ3 = dA3 * (Z3 > 0)
    dW3 = np.dot(dZ3, A2.T)
    db3 = dZ3
    
    dA2 = np.dot(W3.T, dZ3)
    dZ2 = dA2 * (Z2 > 0)
    dW2 = np.dot(dZ2, A1.T)
    db2 = dZ2
    
    dA1 = np.dot(W2.T, dZ2)
    dZ1 = dA1 * (Z1 > 0)
    dW1 = np.dot(dZ1, X.T)
    db1 = dZ1
    
    return dW1, db1, dW2, db2, dW3, db3, dW4, db4, dW5, db5

# Batch training
def train_batch(batch_data, params, alpha=0.001, beta1=0.9, beta2=0.999):
    if not hasattr(train_batch, "m"):
        train_batch.m = [np.zeros_like(p) for p in params]
        train_batch.v = [np.zeros_like(p) for p in params]
        train_batch.t = 0
    
    train_batch.t += 1
    batch_loss = 0
    batch_acc = 0
    grads = None
    
    for pixel_array, label, center in batch_data:
        X = preprocess_image(pixel_array, center)
        y_true = one_hot(label)
        
        cache, A5 = forward(X, params)
        prediction = np.argmax(A5)
        match = int(prediction == np.argmax(y_true))
        loss = -np.sum(y_true * np.log(A5 + 1e-8))
        
        batch_grads = backward(cache, params, y_true)
        
        if grads is None:
            grads = batch_grads
        else:
            grads = [g + bg for g, bg in zip(grads, batch_grads)]
        
        batch_loss += loss
        batch_acc += match
    
    grads = [g/len(batch_data) for g in grads]
    batch_loss /= len(batch_data)
    batch_acc /= len(batch_data)
    
    new_params = []
    for i in range(len(params)):
        train_batch.m[i] = beta1 * train_batch.m[i] + (1 - beta1) * grads[i]
        train_batch.v[i] = beta2 * train_batch.v[i] + (1 - beta2) * (grads[i]**2)
        
        m_hat = train_batch.m[i] / (1 - beta1**train_batch.t)
        v_hat = train_batch.v[i] / (1 - beta2**train_batch.t)
        
        new_param = params[i] - alpha * m_hat / (np.sqrt(v_hat) + 1e-8)
        new_params.append(new_param)
    
    return new_params, batch_loss, batch_acc

def trainedimages():
    #Load no. of trained images
    file = open("geeks.txt", "r")  #! Hardcode file jahan per no. of trained images store hote hain
    content = int(file.read())
    print(content)
    file.close()
    return content

def cleanup(imagecount):
   print("Cleaning up before exit...")
    # Your cleanup code here
   file = open("geeks.txt", "w") #! Hardcode file jahan per no. of trained images store hote hain
   file.write(str(imagecount))
   file.close()

# Define signal handler with parameters
def handle_signal(signum, frame, imagecount):
    print(f"\nSignal {signum} received. Cleaning up...")
    cleanup(imagecount)  # Call cleanup with imagecount
    sys.exit(0)


# Main training loop
def process_csv_rows(image_file, centre_file, batch_size=64, max_epochs=100):
    params = load_parameters()
    best_acc = 0
    loss_history = deque(maxlen=1000)
    accuracy_counter = 0
    current_image_counter = 0
    total_epoch_images = 28770

    image_counter = trainedimages()
    counter = 0

    if image_counter != 0:
        counter = image_counter % total_epoch_images
        epochs = (image_counter - counter) / total_epoch_images
        epoch = epochs + 1

    # Register cleanup
    atexit.register(lambda: cleanup(image_counter))
    signal.signal(signal.SIGINT, lambda s, f: handle_signal(s, f, image_counter))
    signal.signal(signal.SIGTERM, lambda s, f: handle_signal(s, f, image_counter))

    for epoch in range(max_epochs):
        print(f"\nEpoch {epoch + 1}")
        start_time = time.time()

        batch_gen = batch_generator(image_file, centre_file, batch_size)

        for batch_num, batch in enumerate(batch_gen):
            params, loss, acc = train_batch(batch, params)
            loss_history.append(loss)
            acc = acc*100

            W1, b1, W2, b2, W3, b3, W4, b4, W5, b5 = params

            current_image_counter += len(batch)
            image_counter += len(batch)

            if current_image_counter % 100 == 0:
                with open("LossTrack.txt", "a") as f1, open("AccuracyTrack.txt", "a") as f2:
                    f1.write(f"Epoch {epoch}, Image {image_counter}, Loss {loss}\n")
                    f2.write(f"Epoch {epoch}, Image {image_counter}, Accuracy {acc}%\n")

                accuracy_counter = 0
                current_image_counter = 0

                save_parameters(W1, b1, W2, b2, W3, b3, W4, b4, W5, b5)

            if batch_num % 10 == 0:
                print(f"Batch {batch_num}: Loss={loss:.4f}, Acc={acc}%")

        epoch_time = time.time() - start_time
        print(f"Epoch {epoch + 1} completed in {epoch_time:.2f}s")

process_csv_rows("secondshuffle_greyscales (1).csv", "secondshuffle_centres (1).csv")