import tkinter as tk
from tkinter import ttk
import cv2
import mediapipe as mp
import numpy as np
from PIL import Image, ImageTk
import csv
import os
import time
import string


os.system('cls' if os.name == 'nt' else 'clear')

def generate_shell_masked_matrix(pixel_array, center, hidden_size1=47):
    cx, cy = center
    final_data = []
    img_size = 100

    for layer in range(1, hidden_size1 + 1):
        shell_row = [0] * (img_size * img_size)
        
        # Define shell bounds
        for y in range(cy - layer, cy + layer + 1):
            for x in range(cx - layer, cx + layer + 1):
                if x < 0 or x >= img_size or y < 0 or y >= img_size:
                    continue
                
                # Border condition for shell edge
                if x == cx - layer or x == cx + layer or y == cy - layer or y == cy + layer:
                    index = y * img_size + x
                    shell_row[index] = pixel_array[index]
        
        final_data.append(shell_row)
    
    return final_data

def normalize_grayscale_array(arr):
    arr = np.array(arr)
    # Normalize each shell separately and take mean
    normalized_shells = []
    for shell in arr:
        shell = np.array(shell)
        if np.max(shell) > 0:  # Avoid division by zero
            shell = shell / np.max(shell)
        normalized_shells.append(np.mean(shell))
    
    return np.array(normalized_shells).reshape(-1, 1)  # Return as (47, 1)

def preprocess_image(pixel_array, center):
    """Convert image to normalized shell averages"""
    shells = generate_shell_masked_matrix(pixel_array, center, 47)
    final = normalize_grayscale_array(shells)
    return final  # Already (47, 1)

def random_parameters():
    # Layer sizes
    input_size = 47
    hidden_size1 = 64   # First hidden layer
    hidden_size2 = 32   # Second hidden layer
    output_size = 2     # Output layer ("a" and "not a")
    
    # He initialization for ReLU
    W1 = np.random.randn(hidden_size1, input_size) * np.sqrt(2./input_size)
    b1 = np.zeros((hidden_size1, 1))
    
    W2 = np.random.randn(hidden_size2, hidden_size1) * np.sqrt(2./hidden_size1)
    b2 = np.zeros((hidden_size2, 1))
    
    W3 = np.random.randn(output_size, hidden_size2) * np.sqrt(2./hidden_size2)
    b3 = np.zeros((output_size, 1))
    
    return W1, b1, W2, b2, W3, b3

def load_parameters():
    params = {}
    param_names = ['W1', 'b1', 'W2', 'b2', 'W3', 'b3']
    
    # Check if all parameter files exist
    all_exist = all(os.path.exists(f"{name}.csv") for name in param_names)
    
    if all_exist:
        print("Loading existing parameters...")
        try:
            for name in param_names:
                params[name] = np.loadtxt(f"{name}.csv", delimiter=',')
                if name.startswith('b'):
                    params[name] = params[name].reshape(-1, 1)
                elif name == 'W3':
                    # Try new shape first, fall back to old shape if needed
                    try:
                        params[name] = params[name].reshape(2, 32)
                    except ValueError:
                        print("Existing W3 parameters don't match new architecture. Initializing new W3.")
                        params[name] = np.random.randn(2, 32) * np.sqrt(2./32)
                elif name == 'W2':
                    params[name] = params[name].reshape(32, 64)
                elif name == 'W1':
                    params[name] = params[name].reshape(64, 47)
            return (params['W1'], params['b1'], params['W2'], params['b2'], params['W3'], params['b3'])
        except ValueError as e:
            print(f"Parameter shape mismatch: {e}. Initializing new parameters.")
            return random_parameters()
    else:
        print("Initializing new parameters...")
        return random_parameters()

def Leaky_relu(Z, alpha=0.01):
    """Leaky ReLU activation function"""
    return np.where(Z > 0, Z, alpha * Z)

def softmax(Z):
    expZ = np.exp(Z - np.max(Z, axis=0))
    return expZ / np.sum(expZ, axis=0, keepdims=True)

def forward(X, W1, b1, W2, b2, W3, b3):
    # Layer 1 (input to hidden1)
    Z1 = np.dot(W1, X) + b1  # (64,47) @ (47,1) -> (64,1)
    A1 = Leaky_relu(Z1)
    
    # Layer 2 (hidden1 to hidden2)
    Z2 = np.dot(W2, A1) + b2  # (32,64) @ (64,1) -> (32,1)
    A2 = Leaky_relu(Z2)
    
    # Output layer (hidden2 to output)
    Z3 = np.dot(W3, A2) + b3  # (2,32) @ (32,1) -> (2,1)
    A3 = softmax(Z3)
    
    return A3

def train_image(pixel_array, center, W1, b1, W2, b2, W3, b3, alpha=0.001):
    # 1. Preprocess image
    X = preprocess_image(pixel_array, center)  # (47,1)
    
    # 2. Forward pass
    A3 = forward(X, W1, b1, W2, b2, W3, b3)

    # 3. Get predictions and loss
    prediction = np.argmax(A3)
    
    labels = list(string.ascii_uppercase) + ["del", "nothing", "space"]
    return labels[prediction]
    

def process_csv_rows(pixels, centres):
    
    W1, b1, W2, b2, W3, b3 = load_parameters()
    prediction = train_image(pixels, centres, W1, b1, W2, b2, W3, b3)
    print(prediction)

output_dir = "LiveImages"
os.makedirs(output_dir, exist_ok=True)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=True, max_num_hands=1, min_detection_confidence=0.5)

def save_pixels_and_center(pixels, center, prefix="capture"):
    pixel_path = os.path.join(output_dir, f"pixels.csv")
    with open(pixel_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(pixels.tolist())  # single row, no header

    center_path = os.path.join(output_dir, f"centers.csv")
    with open(center_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(center)  # single row, no header

class HandCaptureGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Hand Sign Capture")
        self.root.geometry("720x640")
        self.root.resizable(False, False)

        # Frame for video with border
        self.video_frame = tk.Frame(root, bd=5, relief=tk.SUNKEN)
        self.video_frame.pack(padx=10, pady=10)

        self.video_label = tk.Label(self.video_frame)
        self.video_label.pack()

        # Timer Label
        self.timer_label = tk.Label(root, text="Get ready! Capture in 3", font=("Helvetica", 18))
        self.timer_label.pack(pady=10)

        # Status Label
        self.status_label = tk.Label(root, text="Status: Waiting to start...", font=("Helvetica", 14))
        self.status_label.pack(pady=5)

        # Initialize OpenCV capture
        self.cap = cv2.VideoCapture(0)
        self.countdown = 3  # seconds for countdown
        self.captured = False

        self.update_frame()
        self.update_timer()

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            self.status_label.config(text="Failed to read from camera.")
            self.root.after(30, self.update_frame)
            return

        frame = cv2.flip(frame, 1)  # mirror image
        img_h, img_w, _ = frame.shape

        if not self.captured:
            border_color = (0, 255, 0)  # green before capture
            thickness = 5
            cv2.rectangle(frame, (0, 0), (img_w - 1, img_h - 1), border_color, thickness)
        else:
            border_color = (0, 0, 255)  # red after capture
            thickness = 5
            cv2.rectangle(frame, (0, 0), (img_w - 1, img_h - 1), border_color, thickness)

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb_frame)
        imgtk = ImageTk.PhotoImage(image=img)

        self.video_label.imgtk = imgtk
        self.video_label.configure(image=imgtk)

        if not self.captured:
            self.root.after(30, self.update_frame)  # continue updating frames
        else:
            # After capture, wait 3 seconds then close app
            self.root.after(3000, self.close)

    def update_timer(self):
        if self.countdown > 0:
            self.timer_label.config(text=f"Get ready! Capture in {self.countdown}")
            self.countdown -= 1
            self.root.after(1000, self.update_timer)
        else:
            self.timer_label.config(text="Capturing image now...")
            self.capture_image()

    def capture_image(self):
        ret, frame = self.cap.read()
        if not ret:
            self.status_label.config(text="Failed to capture image.")
            return

        frame = cv2.flip(frame, 1)

        resized_200 = cv2.resize(frame, (200, 200))
        rgb_200 = cv2.cvtColor(resized_200, cv2.COLOR_BGR2RGB)
        results = hands.process(rgb_200)

        if results.multi_hand_landmarks:
            hand_landmarks = results.multi_hand_landmarks[0]
            lm9 = hand_landmarks.landmark[9]

            x_200 = int(lm9.x * 200)
            y_200 = int(lm9.y * 200)

            gray_200 = cv2.cvtColor(resized_200, cv2.COLOR_BGR2GRAY)
            resized_100 = cv2.resize(gray_200, (100, 100))

            scale = 100 / 200
            x_100 = int(x_200 * scale)
            y_100 = int(y_200 * scale)

            pixels_flat = resized_100.flatten()

            timestamp = int(time.time())
            save_pixels_and_center(pixels_flat, (x_100, y_100), prefix=f"capture_{timestamp}")

            # Draw circle at landmark #9 on 200x200 image
            cv2.circle(resized_200, (x_200, y_200), 7, (0, 255, 0), -1)

            # Show captured image with landmark in GUI
            img_rgb = cv2.cvtColor(resized_200, cv2.COLOR_BGR2RGB)
            img_pil = Image.fromarray(img_rgb)
            imgtk = ImageTk.PhotoImage(img_pil)

            self.video_label.imgtk = imgtk
            self.video_label.configure(image=imgtk)

            self.status_label.config(text=f"Image captured and saved! Landmark #9 at ({x_100}, {y_100})")
            self.captured = True

             # ---> Load saved CSV files into variables: pixels and center
            pixels_path = os.path.join(output_dir, "pixels.csv")
            centers_path = os.path.join(output_dir, "centers.csv")

            with open(pixels_path, "r") as f:
                reader = csv.reader(f)
                pixels = np.array(next(reader), dtype=np.uint8)  # shape: (10000,)
                pixels.reshape((1, 10000))

            with open(centers_path, "r") as f:
                reader = csv.reader(f)
                center = tuple(map(int, next(reader)))  # (x, y)
                os.system('cls')
                process_csv_rows(pixels,center)

        else:
            self.status_label.config(text="No hand detected! Please try again.")
            self.captured = True

    def close(self):
        self.cap.release()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = HandCaptureGUI(root)
    root.mainloop()