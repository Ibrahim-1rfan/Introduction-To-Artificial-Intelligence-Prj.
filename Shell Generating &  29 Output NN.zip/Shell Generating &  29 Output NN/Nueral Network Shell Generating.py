import tkinter as tk
from tkinter import ttk
import cv2
import mediapipe as mp
import numpy as np
from PIL import Image, ImageTk
import csv
import os
import time
import string

# Clear console for cleaner output
os.system('cls' if os.name == 'nt' else 'clear')

#Custom radial shell extraction implemtation function
def generate_shell_masked_matrix(pixel_array, center, hidden_size1=47):
   #?Extracting concentric square shell from image center.
    cx, cy = center
    img_size = 100
    final_data = np.zeros((hidden_size1, img_size * img_size), dtype=np.float32)
    
    for layer in range(1, hidden_size1 + 1):
        # Calculate current shell boundaries
        min_x, max_x = max(cx - layer, 0), min(cx + layer, img_size - 1)
        min_y, max_y = max(cy - layer, 0), min(cy + layer, img_size - 1)
        
        # Extract top and bottom borders of shell
        if min_y >= 0:
            indices = np.arange(min_y * img_size + min_x, min_y * img_size + max_x + 1)
            final_data[layer-1, indices] = pixel_array[indices]
        if max_y < img_size:
            indices = np.arange(max_y * img_size + min_x, max_y * img_size + max_x + 1)
            final_data[layer-1, indices] = pixel_array[indices]
        
        # Extract left and right borders (excluding corners)
        if min_x >= 0:
            y_range = np.arange(max(min_y + 1, 0), min(max_y, img_size - 1))
            indices = y_range * img_size + min_x
            final_data[layer-1, indices] = pixel_array[indices]
        if max_x < img_size:
            y_range = np.arange(max(min_y + 1, 0), min(max_y, img_size - 1))
            indices = y_range * img_size + max_x
            final_data[layer-1, indices] = pixel_array[indices]
    
    return final_data


def normalize_grayscale_array(arr):
   #?Normalize grayscale array to [0, 1] range
    arr = np.array(arr, dtype=np.float32)
    max_vals = np.max(arr, axis=1, keepdims=True)
    np.divide(arr, max_vals + 1e-8, out=arr, where=max_vals > 0)  # Avoid division by zero
    return np.mean(arr, axis=1).reshape(-1, 1)  # Reduce to 1D features

def preprocess_image(pixel_array, center):
    #* Full preprocessing pipeline: shell extraction -> normalization
    shells = generate_shell_masked_matrix(pixel_array, center)
    return normalize_grayscale_array(shells)

# NETWORK INITIALIZATION
def random_parameters():
    """Initialize weights for better training"""
    input_size = 47
    hidden_size1 = 256  # First hidden layer size
    hidden_size2 = 128  # Second hidden layer
    hidden_size3 = 64   # Third hidden layer
    output_size = 29    # 26 letters + del/nothing/space
    
    # Layer 1 weights (input -> hidden1)
    W1 = np.random.randn(hidden_size1, input_size).astype(np.float32) * np.sqrt(2./(input_size + hidden_size1))
    b1 = np.zeros((hidden_size1, 1), dtype=np.float32)
    
    # Layer 2 weights (hidden1 -> hidden2)
    W2 = np.random.randn(hidden_size2, hidden_size1).astype(np.float32) * np.sqrt(2./(hidden_size1 + hidden_size2))
    b2 = np.zeros((hidden_size2, 1), dtype=np.float32)
    
    # Layer 3 weights (hidden2 -> hidden3)
    W3 = np.random.randn(hidden_size3, hidden_size2).astype(np.float32) * np.sqrt(2./(hidden_size2 + hidden_size3))
    b3 = np.zeros((hidden_size3, 1), dtype=np.float32)
    
    # Output layer weights (hidden3 -> output)
    W4 = np.random.randn(output_size, hidden_size3).astype(np.float32) * np.sqrt(2./(hidden_size3 + output_size))
    b4 = np.zeros((output_size, 1), dtype=np.float32)
    
    return W1, b1, W2, b2, W3, b3, W4, b4


def load_parameters():
    #? Load saved weights or initialize new ones if none exist
    param_names = ['W1', 'b1', 'W2', 'b2', 'W3', 'b3', 'W4', 'b4']
    expected_shapes = [(256, 47), (256, 1), (128, 256), (128, 1), 
                      (64, 128), (64, 1), (29, 64), (29, 1)]
    
    if all(os.path.exists(f"{name}.csv") for name in param_names):
        print("Loading saved model parameters...")
        params = []
        for name, shape in zip(param_names, expected_shapes):
            param = np.loadtxt(f"{name}.csv", delimiter=',', dtype=np.float32)
            if param.shape != shape:
                print(f"Shape mismatch in {name}, initializing new parameters")
                return random_parameters()
            params.append(param.reshape(shape))  # Ensure correct shape
        return tuple(params)
    else:
        print("No saved parameters found, initializing new model")
        return random_parameters()


def Leaky_relu(Z, alpha=0.1): #Activation function
    # Leaky ReLU with configurable negative slope
    return np.maximum(Z, alpha * Z)

def softmax(Z): #Activation function
    expZ = np.exp(Z - np.max(Z))  # Shift values for stability
    return expZ / (np.sum(expZ, axis=0, keepdims=True) + 1e-8)  # Add epsilon

# Forward Propagation to predict output
def forward(X, W1, b1, W2, b2, W3, b3, W4, b4):
    
    # Layer 1 with batch norm
    Z1 = np.dot(W1, X) + b1
    A1 = Leaky_relu(Z1)
    A1_mean = np.mean(A1, axis=1, keepdims=True)
    A1_std = np.std(A1, axis=1, keepdims=True)
    A1 = (A1 - A1_mean) / (A1_std + 1e-8)
    
    # Layer 2 with batch norm
    Z2 = np.dot(W2, A1) + b2
    A2 = Leaky_relu(Z2)
    A2_mean = np.mean(A2, axis=1, keepdims=True)
    A2_std = np.std(A2, axis=1, keepdims=True)
    A2 = (A2 - A2_mean) / (A2_std + 1e-8)
    
    # Layer 3 with batch norm
    Z3 = np.dot(W3, A2) + b3
    A3 = Leaky_relu(Z3)
    A3_mean = np.mean(A3, axis=1, keepdims=True)
    A3_std = np.std(A3, axis=1, keepdims=True)
    A3 = (A3 - A3_mean) / (A3_std + 1e-8)
    
    # Output layer (softmax)
    Z4 = np.dot(W4, A3) + b4
    A4 = softmax(Z4)
    
    # Cache values needed for backprop
    return A4

def train_image(pixel_array, center, W1, b1, W2, b2, W3, b3, W4, b4):
    # Forward pass
    X = preprocess_image(pixel_array, center)
    A4 = forward(X, W1, b1, W2, b2, W3, b3, W4, b4)
    prediction = np.argmax(A4)

    labels = list(string.ascii_uppercase) + ["del", "nothing", "space"]
    return labels[prediction]

def process_csv_rows(pixels, centres):
    
    W1, b1, W2, b2, W3, b3, W4, b4 = load_parameters()
    prediction = train_image(pixels, centres, W1, b1, W2, b2, W3, b3, W4, b4)
    print(prediction)

output_dir = "LiveImages"
os.makedirs(output_dir, exist_ok=True)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=True, max_num_hands=1, min_detection_confidence=0.5)

def save_pixels_and_center(pixels, center, prefix="capture"):
    pixel_path = os.path.join(output_dir, f"pixels.csv")
    with open(pixel_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(pixels.tolist())

    center_path = os.path.join(output_dir, f"centers.csv")
    with open(center_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(center)

class HandCaptureGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Hand Sign Recognition")
        self.root.geometry("720x640")
        self.root.resizable(False, False)

        # Main container
        self.main_frame = tk.Frame(root, bg="#f0f0f0")
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # Video feed frame
        self.video_frame = tk.Frame(self.main_frame, bd=3, relief=tk.GROOVE)
        self.video_frame.pack(padx=10, pady=10)

        self.video_label = tk.Label(self.video_frame)
        self.video_label.pack()

        # Information panel
        self.info_frame = tk.Frame(self.main_frame, bg="#f0f0f0")
        self.info_frame.pack(pady=10)

        # Prediction display
        self.prediction_label = tk.Label(self.info_frame, text="Prediction: ", 
                                       font=("Arial", 24, "bold"), bg="#f0f0f0")
        self.prediction_label.pack(side=tk.LEFT, padx=20)

        # Timer display
        self.timer_label = tk.Label(self.info_frame, text="00", 
                                   font=("Arial", 24), bg="#f0f0f0", fg="#333333")
        self.timer_label.pack(side=tk.LEFT, padx=20)

        # Status bar
        self.status_label = tk.Label(root, text="Status: Preparing system...", 
                                    bd=1, relief=tk.SUNKEN, anchor=tk.W, 
                                    font=("Arial", 12), bg="#e0e0e0")
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

        # Initialize camera
        self.cap = cv2.VideoCapture(0)
        self.countdown = 3
        self.captured = False

        # Start interface updates
        self.update_frame()
        self.update_timer()

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            self.status_label.config(text="Error: Camera not detected!")
            return

        frame = cv2.flip(frame, 1)
        img_h, img_w, _ = frame.shape

        # Draw camera border
        border_color = (0, 165, 255) if self.captured else (0, 200, 0)
        cv2.rectangle(frame, (0, 0), (img_w-1, img_h-1), border_color, 3)

        # Convert to Tkinter format
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb_frame)
        imgtk = ImageTk.PhotoImage(image=img)

        self.video_label.imgtk = imgtk
        self.video_label.configure(image=imgtk)

        if not self.captured:
            self.root.after(30, self.update_frame)

    def update_timer(self):
        if self.countdown > 0:
            self.timer_label.config(text=str(self.countdown))
            self.countdown -= 1
            self.root.after(1000, self.update_timer)
        else:
            self.timer_label.config(text="GO!")
            self.capture_image()

    def capture_image(self):
        ret, frame = self.cap.read()
        if not ret:
            self.status_label.config(text="Error capturing image!")
            return

        frame = cv2.flip(frame, 1)
        resized_200 = cv2.resize(frame, (200, 200))
        rgb_200 = cv2.cvtColor(resized_200, cv2.COLOR_BGR2RGB)
        results = hands.process(rgb_200)

        if results.multi_hand_landmarks:
            hand_landmarks = results.multi_hand_landmarks[0]
            lm9 = hand_landmarks.landmark[9]

            x_200 = int(lm9.x * 200)
            y_200 = int(lm9.y * 200)

            gray_200 = cv2.cvtColor(resized_200, cv2.COLOR_BGR2GRAY)
            resized_100 = cv2.resize(gray_200, (100, 100))

            scale = 100 / 200
            x_100 = int(x_200 * scale)
            y_100 = int(y_200 * scale)

            pixels_flat = resized_100.flatten()

            save_pixels_and_center(pixels_flat, (x_100, y_100))

            # Process image and get prediction
            prediction = process_csv_rows(pixels_flat, (x_100, y_100))
            
            # Update GUI with prediction
            self.prediction_label.config(text=f"Prediction: {prediction}")
            self.status_label.config(text=f"Success: Detected '{prediction}' sign!")
            
            # Visual feedback
            cv2.circle(resized_200, (x_200, y_200), 7, (0, 255, 0), -1)
            img_rgb = cv2.cvtColor(resized_200, cv2.COLOR_BGR2RGB)
            img_pil = Image.fromarray(img_rgb)
            imgtk = ImageTk.PhotoImage(img_pil)

            self.video_label.imgtk = imgtk
            self.video_label.configure(image=imgtk)
            self.captured = True

            # Reset after 3 seconds
            self.root.after(3000, self.reset_interface)
        else:
            self.status_label.config(text="Error: No hand detected!")
            self.captured = True
            self.root.after(3000, self.reset_interface)

    def reset_interface(self):
        self.captured = False
        self.countdown = 3
        self.prediction_label.config(text="Prediction: ")
        self.timer_label.config(text="00")
        self.status_label.config(text="Status: Ready for next capture")
        self.update_frame()
        self.update_timer()

    def close(self):
        self.cap.release()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = HandCaptureGUI(root)
    root.mainloop()