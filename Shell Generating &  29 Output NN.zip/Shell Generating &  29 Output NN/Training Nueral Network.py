import numpy as np
import csv
import os
import atexit
import signal
import sys
import time
from collections import deque

# Clear console for cleaner output
os.system('cls' if os.name == 'nt' else 'clear')

#Custom radial shell extraction implemtation function
def generate_shell_masked_matrix(pixel_array, center, hidden_size1=47):
   #?Extracting concentric square shell from image center.
    cx, cy = center
    img_size = 100
    final_data = np.zeros((hidden_size1, img_size * img_size), dtype=np.float32)
    
    for layer in range(1, hidden_size1 + 1):
        # Calculate current shell boundaries
        min_x, max_x = max(cx - layer, 0), min(cx + layer, img_size - 1)
        min_y, max_y = max(cy - layer, 0), min(cy + layer, img_size - 1)
        
        # Extract top and bottom borders of shell
        if min_y >= 0:
            indices = np.arange(min_y * img_size + min_x, min_y * img_size + max_x + 1)
            final_data[layer-1, indices] = pixel_array[indices]
        if max_y < img_size:
            indices = np.arange(max_y * img_size + min_x, max_y * img_size + max_x + 1)
            final_data[layer-1, indices] = pixel_array[indices]
        
        # Extract left and right borders (excluding corners)
        if min_x >= 0:
            y_range = np.arange(max(min_y + 1, 0), min(max_y, img_size - 1))
            indices = y_range * img_size + min_x
            final_data[layer-1, indices] = pixel_array[indices]
        if max_x < img_size:
            y_range = np.arange(max(min_y + 1, 0), min(max_y, img_size - 1))
            indices = y_range * img_size + max_x
            final_data[layer-1, indices] = pixel_array[indices]
    
    return final_data


def normalize_grayscale_array(arr):
   #?Normalize grayscale array to [0, 1] range
    arr = np.array(arr, dtype=np.float32)
    max_vals = np.max(arr, axis=1, keepdims=True)
    np.divide(arr, max_vals + 1e-8, out=arr, where=max_vals > 0)  # Avoid division by zero
    return np.mean(arr, axis=1).reshape(-1, 1)  # Reduce to 1D features

def preprocess_image(pixel_array, center):
    #* Full preprocessing pipeline: shell extraction -> normalization
    shells = generate_shell_masked_matrix(pixel_array, center)
    return normalize_grayscale_array(shells)

# NETWORK INITIALIZATION
def random_parameters():
    """Initialize weights for better training"""
    input_size = 47
    hidden_size1 = 256  # First hidden layer size
    hidden_size2 = 128  # Second hidden layer
    hidden_size3 = 64   # Third hidden layer
    output_size = 29    # 26 letters + del/nothing/space
    
    # Layer 1 weights (input -> hidden1)
    W1 = np.random.randn(hidden_size1, input_size).astype(np.float32) * np.sqrt(2./(input_size + hidden_size1))
    b1 = np.zeros((hidden_size1, 1), dtype=np.float32)
    
    # Layer 2 weights (hidden1 -> hidden2)
    W2 = np.random.randn(hidden_size2, hidden_size1).astype(np.float32) * np.sqrt(2./(hidden_size1 + hidden_size2))
    b2 = np.zeros((hidden_size2, 1), dtype=np.float32)
    
    # Layer 3 weights (hidden2 -> hidden3)
    W3 = np.random.randn(hidden_size3, hidden_size2).astype(np.float32) * np.sqrt(2./(hidden_size2 + hidden_size3))
    b3 = np.zeros((hidden_size3, 1), dtype=np.float32)
    
    # Output layer weights (hidden3 -> output)
    W4 = np.random.randn(output_size, hidden_size3).astype(np.float32) * np.sqrt(2./(hidden_size3 + output_size))
    b4 = np.zeros((output_size, 1), dtype=np.float32)
    
    return W1, b1, W2, b2, W3, b3, W4, b4


def load_parameters():
    #? Load saved weights or initialize new ones if none exist
    param_names = ['W1', 'b1', 'W2', 'b2', 'W3', 'b3', 'W4', 'b4']
    expected_shapes = [(256, 47), (256, 1), (128, 256), (128, 1), 
                      (64, 128), (64, 1), (29, 64), (29, 1)]
    
    if all(os.path.exists(f"{name}.csv") for name in param_names):
        print("Loading saved model parameters...")
        params = []
        for name, shape in zip(param_names, expected_shapes):
            param = np.loadtxt(f"{name}.csv", delimiter=',', dtype=np.float32)
            if param.shape != shape:
                print(f"Shape mismatch in {name}, initializing new parameters")
                return random_parameters()
            params.append(param.reshape(shape))  # Ensure correct shape
        return tuple(params)
    else:
        print("No saved parameters found, initializing new model")
        return random_parameters()


def Leaky_relu(Z, alpha=0.1): #Activation function
    # Leaky ReLU with configurable negative slope
    return np.maximum(Z, alpha * Z)

def softmax(Z): #Activation function
    expZ = np.exp(Z - np.max(Z))  # Shift values for stability
    return expZ / (np.sum(expZ, axis=0, keepdims=True) + 1e-8)  # Add epsilon

# Forward Propagation to predict output
def forward(X, W1, b1, W2, b2, W3, b3, W4, b4):
    
    # Layer 1 with batch norm
    Z1 = np.dot(W1, X) + b1
    A1 = Leaky_relu(Z1)
    A1_mean = np.mean(A1, axis=1, keepdims=True)
    A1_std = np.std(A1, axis=1, keepdims=True)
    A1 = (A1 - A1_mean) / (A1_std + 1e-8)
    
    # Layer 2 with batch norm
    Z2 = np.dot(W2, A1) + b2
    A2 = Leaky_relu(Z2)
    A2_mean = np.mean(A2, axis=1, keepdims=True)
    A2_std = np.std(A2, axis=1, keepdims=True)
    A2 = (A2 - A2_mean) / (A2_std + 1e-8)
    
    # Layer 3 with batch norm
    Z3 = np.dot(W3, A2) + b3
    A3 = Leaky_relu(Z3)
    A3_mean = np.mean(A3, axis=1, keepdims=True)
    A3_std = np.std(A3, axis=1, keepdims=True)
    A3 = (A3 - A3_mean) / (A3_std + 1e-8)
    
    # Output layer (softmax)
    Z4 = np.dot(W4, A3) + b4
    A4 = softmax(Z4)
    
    # Cache values needed for backprop
    cache = (X, Z1, A1, Z2, A2, Z3, A3, A4, A1_mean, A1_std, A2_mean, A2_std, A3_mean, A3_std)
    return cache, A4

# LABEL ENCODING
def one_hot(label): #? Convert text label to one-hot encoded vector
    
    classes = [chr(i) for i in range(ord('A'), ord('Z')+1)] + ['del', 'nothing', 'space']
    label_to_index = {cls:idx for idx, cls in enumerate(classes)}
    one_hot_vector = np.zeros((29, 1), dtype=np.float32)
    one_hot_vector[label_to_index[label]] = 1
    return one_hot_vector

#Backpropagation to train weights and biases
def backward(cache, W2, W3, W4, y_true): #?Compute gradients with stochastic gradient descent.
    
    X, Z1, A1, Z2, A2, Z3, A3, A4, A1_mean, A1_std, A2_mean, A2_std, A3_mean, A3_std = cache
    
    # Output layer gradient
    dZ4 = A4 - y_true
    
    # Gradient clipping to prevent explosions
    max_grad_norm = 1.0
    grad_norm = np.linalg.norm(dZ4)
    if grad_norm > max_grad_norm:
        dZ4 = dZ4 * (max_grad_norm / (grad_norm + 1e-8))
    
    # Weight updates for output layer
    dW4 = np.dot(dZ4, A3.T)
    db4 = dZ4
    
    # Backprop through layer 3 with batch norm adjustment
    dA3 = np.dot(W4.T, dZ4)
    dZ3 = dA3 * (Z3 > 0)  # ReLU derivative
    dZ3 = dZ3 / (A3_std + 1e-8)  # Account for batch norm
    
    if np.linalg.norm(dZ3) > max_grad_norm:
        dZ3 = dZ3 * (max_grad_norm / (np.linalg.norm(dZ3) + 1e-8))
    
    dW3 = np.dot(dZ3, A2.T)
    db3 = dZ3
    
    # Backprop through layer 2
    dA2 = np.dot(W3.T, dZ3)
    dZ2 = dA2 * (Z2 > 0)
    dZ2 = dZ2 / (A2_std + 1e-8)
    
    if np.linalg.norm(dZ2) > max_grad_norm:
        dZ2 = dZ2 * (max_grad_norm / (np.linalg.norm(dZ2) + 1e-8))
    
    dW2 = np.dot(dZ2, A1.T)
    db2 = dZ2
    
    # Backprop through layer 1
    dA1 = np.dot(W2.T, dZ2)
    dZ1 = dA1 * (Z1 > 0)
    dZ1 = dZ1 / (A1_std + 1e-8)
    
    if np.linalg.norm(dZ1) > max_grad_norm:
        dZ1 = dZ1 * (max_grad_norm / (np.linalg.norm(dZ1) + 1e-8))
    
    dW1 = np.dot(dZ1, X.T)
    db1 = dZ1
    
    return dW1, db1, dW2, db2, dW3, db3, dW4, db4

#Saving model weights and biases to CSV files
def save_parameters(W1, b1, W2, b2, W3, b3, W4, b4):
    """Save model weights to CSV files"""
    for name, param in zip(['W1', 'b1', 'W2', 'b2', 'W3', 'b3', 'W4', 'b4'],
                          [W1, b1, W2, b2, W3, b3, W4, b4]):
        np.savetxt(f"{name}.csv", param, delimiter=',')

#Training function
def train_image(pixel_array, label, center, W1, b1, W2, b2, W3, b3, W4, b4, alpha=0.001, momentum=0.9):
    """Single training step with Momentum + RMSprop optimization"""
    # Forward pass
    X = preprocess_image(pixel_array, center)
    cache, A4 = forward(X, W1, b1, W2, b2, W3, b3, W4, b4)
    
    # Calculate loss and accuracy
    y_true = one_hot(label)
    prediction = np.argmax(A4)
    match = int(prediction == np.argmax(y_true))
    loss = -np.sum(y_true * np.log(A4 + 1e-8))  # Cross-entropy
    
    # Backward pass
    grads = backward(cache, W2, W3, W4, y_true)
    
    # Initialize optimizer state if first call
    if not hasattr(train_image, "momentum_buffers"):
        train_image.momentum_buffers = [np.zeros_like(p) for p in [W1, b1, W2, b2, W3, b3, W4, b4]]
        train_image.rmsprop_buffers = [np.zeros_like(p) for p in [W1, b1, W2, b2, W3, b3, W4, b4]]
    
    # Update parameters with Momentum + RMSprop
    params = [W1, b1, W2, b2, W3, b3, W4, b4]
    updated_params = []
    
    for i in range(len(params)):
        # Momentum update
        train_image.momentum_buffers[i] = momentum * train_image.momentum_buffers[i] + (1 - momentum) * grads[i]
        
        # RMSprop update
        train_image.rmsprop_buffers[i] = 0.9 * train_image.rmsprop_buffers[i] + 0.1 * (grads[i]**2)
        
        # Combined update
        update = train_image.momentum_buffers[i] / (np.sqrt(train_image.rmsprop_buffers[i]) + 1e-8)
        updated_params.append(params[i] - alpha * update)
    
    return (*updated_params, loss, match)


def trainedimages():
    #Tracks number of images processed across runs.
    try:
        with open("geeks.txt", "r") as file:
            return int(file.read())
    except:
        return 0

#* Save the current training state before exiting terminal
def cleanup(image_counter):  
    print("Saving training state before exit...")
    with open("geeks.txt", "w") as file:
        file.write(str(image_counter))

def handle_signal(signum, frame, image_counter):
    # Handle termination signals (Ctrl+C or kill command)
    print(f"\nTraining interrupted! Saving progress...")
    cleanup(image_counter)
    sys.exit(0)

# LEARNING RATE SCHEDULING
def adjust_learning_rate(current_lr, loss_history, min_lr=1e-5, max_lr=1e-2):
    """Dynamically adjust learning rate based on recent loss trends"""
    if len(loss_history) < 10:
        return current_lr
    
    # Calculate improvement over last 10% of history
    window_size = max(10, len(loss_history) // 10)
    recent_loss = np.mean(list(loss_history)[-window_size:])
    prev_loss = np.mean(list(loss_history)[-2*window_size:-window_size])
    
    if recent_loss > prev_loss * 0.999:  # No improvement
        return max(current_lr * 0.5, min_lr)  # Reduce LR
    elif recent_loss < prev_loss * 0.99:  # Good improvement
        return min(current_lr * 1.05, max_lr)  # Increase LR
    else:
        return current_lr  # Keep same

# MAIN TRAINING FUNCTION
def process_csv_rows(image_file, centre_file):
    """Core training pipeline"""
    # Initialize model and training state
    W1, b1, W2, b2, W3, b3, W4, b4 = load_parameters()
    alpha = 0.001  # Initial learning rate
    epoch = 0
    max_epochs = 100
    save_interval = 1000
    accuracy_counter = 0
    current_image_counter = 0
    total_epoch_images = 28770
    loss_history = deque(maxlen=1000)  # Rolling window of losses

    # Resume from saved state if available
    image_counter = trainedimages()
    counter = image_counter % total_epoch_images
    epoch = image_counter // total_epoch_images

    # Setup graceful exit handlers
    atexit.register(lambda: cleanup(image_counter))
    signal.signal(signal.SIGINT, lambda s, f: handle_signal(s, f, image_counter))
    signal.signal(signal.SIGTERM, lambda s, f: handle_signal(s, f, image_counter))

    # Epoch loop
    while epoch < max_epochs:
        print(f"\nStarting Epoch {epoch + 1}/{max_epochs}")
        epoch_loss = []
        start_time = time.time()

        with open(image_file, 'r') as img_f, open(centre_file, 'r') as cntr_f:
            img_reader = csv.reader(img_f)
            cntr_reader = csv.reader(cntr_f)
            
            # Skip already processed images
            for _ in range(counter):
                next(img_reader)
                next(cntr_reader)
            
            # Process each image in epoch
            for img_row, cntr_row in zip(img_reader, cntr_reader):
                label = img_row[0]
                pixels = np.array(img_row[1:], dtype=np.float32)
                centre = (int(cntr_row[0]), int(cntr_row[1]))
                
                # Train on single image
                W1, b1, W2, b2, W3, b3, W4, b4, loss, match = train_image(
                    pixels, label, centre, W1, b1, W2, b2, W3, b3, W4, b4, alpha)
                
                # Update tracking metrics
                epoch_loss.append(loss)
                loss_history.append(loss)
                image_counter += 1
                current_image_counter += 1
                accuracy_counter += match

                # Periodic status updates
                if image_counter % 100 == 0:
                    avg_loss = np.mean(epoch_loss[-100:])
                    current_accuracy = accuracy_counter / max(1, current_image_counter)
                    print(f"Image {image_counter}: Loss={avg_loss:.4f}, LR={alpha:.6f}, Acc={current_accuracy:.2%}")
                    alpha = adjust_learning_rate(alpha, loss_history)

                # Model checkpointing
                if image_counter % save_interval == 0:
                    save_parameters(W1, b1, W2, b2, W3, b3, W4, b4)
                    print(f"Checkpoint saved at {image_counter} images")

                # Detailed logging
                if image_counter % 2000 == 0:
                    with open("LossTrack.txt", "a") as f1, open("AccuracyTrack.txt", "a") as f2:
                        avg_loss = np.mean(epoch_loss[-2000:])
                        accuracy = accuracy_counter / current_image_counter
                        f1.write(f"Epoch {epoch+1}, Image {image_counter}, Loss {avg_loss:.4f}\n")
                        f2.write(f"Epoch {epoch+1}, Image {image_counter}, Accuracy {accuracy:.2%}\n")
                    accuracy_counter = 0
                    current_image_counter = 0

        # Epoch completion
        epoch += 1
        counter = 0  # Reset for new epoch
        epoch_time = time.time() - start_time
        print(f"Epoch {epoch} completed in {epoch_time:.2f}s")
        print(f"Total images processed: {image_counter}")
        print(f"Current learning rate: {alpha:.6f}")
        save_parameters(W1, b1, W2, b2, W3, b3, W4, b4)  # Final save

# Start training
process_csv_rows("secondshuffle_greyscales.csv", "secondshuffle_centres.csv")